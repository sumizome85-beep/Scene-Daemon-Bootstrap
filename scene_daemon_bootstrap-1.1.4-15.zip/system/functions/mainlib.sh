#!/system/bin/sh
# Scene Daemon Bootstrap - shared library
# Sourced by service.sh / action.sh, and by the CLI in system/bin.
# Provides payload provisioning, daemon supervision, policy enforcement and
# environment diagnostics.

scene="com.omarea.vtools"
port=""

SOURCE_DAEMON="/storage/emulated/0/Android/data/$scene/daemon"
SOURCE_BUSYBOX="/storage/emulated/0/Android/data/$scene/toolkit/busybox"
BINDER_SO="/storage/emulated/0/Android/data/$scene/binder.so"

STARTER_PATH="/data/local/tmp/scene-daemon"
TARGET_BUSYBOX="/data/local/tmp/toolkit/busybox"
TOOLKIT="/data/local/tmp/toolkit"

LOG_FILE="${SDB_LOG:-/data/local/tmp/scene_daemon_bootstrap.log}"
ENV_TIMEOUT="${SDB_ENV_TIMEOUT:-60}"
PROGRESS_FILE="${SDB_PROGRESS:-/data/local/tmp/.scene_daemon_bootstrap.progress}"
PAYLOAD_TIMEOUT="${SDB_PAYLOAD_TIMEOUT:-30}"
START_TIMEOUT="${SDB_START_TIMEOUT:-3}"
TERM_TIMEOUT="${SDB_TERM_TIMEOUT:-5}"
# Set to 0 to provision and spawn without launching the Scene UI.
LAUNCH_SCENE="${SDB_LAUNCH_SCENE:-1}"

if [ -z "${SDB_MODDIR:-}" ]; then
  SDB_MODDIR=$(cd "$(dirname "$0")/../.." 2>/dev/null && pwd)
fi
MODDIR="$SDB_MODDIR"

# Single-line, fixed layout: [MM-DD HH:MM:SS] [LEVEL] description.
# The level is derived from the message so call sites stay unchanged, and the
# timestamp is attached once here instead of being added per call.
log_level() {
  case "$1" in
    # A detection report is a reading, not a warning, even though it names
    # states like "not resident".
    *"Detected:"*) echo INFO ;;
    *"Fail"*|*"Error:"*|*"Refused:"*|*"Abort"*) echo ERROR ;;
    *"Warning:"*|*"not resident"*|*"unavailable"*) echo WARN ;;
    *"OK"*|*"Provisioned:"*|*"Applied:"*|*"Terminated"*|*"Purged"*) echo OK ;;
    *) echo INFO ;;
  esac
}

log() {
  # Blank separators used to emit a bare timestamp row with nothing after it.
  [ -z "$*" ] && return 0
  _lvl=$(log_level "$*")
  echo "[$(date '+%m-%d %H:%M:%S')] [$_lvl] $*"
  echo "[$(date '+%m-%d %H:%M:%S')] [$_lvl] $*" >>"$LOG_FILE" 2>/dev/null
}

# toybox/toolbox sleep accepts fractional seconds; fall back to a whole second
# where it does not. A full second of dead wait right after the payload is
# provisioned is what made the routine look stalled before "Scene-Daemon OK".
sleep_frac() {
  sleep "$1" 2>/dev/null || sleep 1
}

# Package probe. "pm path <pkg>" resolves one package; enumerating every
# installed package with "list packages" is an order of magnitude slower and
# was the dominant cost of a status query.
_pkg_installed() {
  if command -v pm >/dev/null 2>&1; then
    pm path "$scene" 2>/dev/null | grep -q "^package:" && return 0
    return 1
  fi
  cmd package list packages 2>/dev/null | grep -q "^package:$scene$"
}

await_payload() {
  i=0
  while [ ! -f "$1" ]; do
    i=$((i + 1))
    [ "$i" -ge "$PAYLOAD_TIMEOUT" ] && return 1
    sleep 1
  done
  return 0
}

# --- process discovery -------------------------------------------------------
# Layered lookups: the different Android userspace variants (toybox, toolbox,
# busybox) disagree on flags and column order, so every result is validated
# before use and /proc is the last resort.

_ps_pids() {
  # $1 = ps flag set, $2 = awk field holding the PID
  ps $1 2>/dev/null |
    grep -E "scene-daemon" |
    grep -vE "grep|awk|scene-bootstrap|daemon_pids|_ps_pids" |
    awk '{print $'"$2"'}' | grep -E '^[0-9]+$'
}

_proc_pids() {
  for d in /proc/[0-9]*; do
    pid=${d#/proc/}
    cmd=$(cat "$d/cmdline" 2>/dev/null)
    case "$cmd" in
      *scene-daemon*) echo "$pid" ;;
    esac
  done
}

# Reject pids whose command line only matched incidentally: a pgrep/ps
# invocation carrying the pattern on its own command line, or the lookup
# helper itself.
# A pid only counts as the daemon if it really is the payload: either its
# argv[0] resolves to scene-daemon, or its command line names the deployed
# path. Matching the bare string "scene-daemon" also catches pgrep, pkill and
# any shell that merely mentions it -- which is how a stopped daemon could
# still look resident.
# Accept only a process that actually IS the daemon. A shell running
# `sh -c "... /data/local/tmp/scene-daemon ..."` also has the path somewhere in
# its command line, and treating that as resident is what made the panel still
# report "running" right after the daemon had been stopped.
_valid_pid() {
  c=$(cat /proc/$1/cmdline 2>/dev/null) || return 1
  [ -n "$c" ] || return 1

  # Kill switched to yes/no wording elsewhere; keep the check self-contained.
  case "$1" in
    *[!0-9]*) return 1 ;;
  esac
  [ -d "/proc/$1" ] || return 1

  argv0=$(echo "$c" | tr '\0' '\n' | head -1)
  [ -n "$argv0" ] || return 1

  # Launched directly: the payload itself is argv[0].
  case "$argv0" in
    "$STARTER_PATH"|*/scene-daemon) return 0 ;;
  esac

  # Launched through a shell: accept only when the payload is the very next
  # argument, i.e. `sh /data/local/tmp/scene-daemon`. A `sh -c` whose command
  # string merely mentions that path is not the daemon.
  argv1=$(echo "$c" | tr '\0' '\n' | sed -n 2p)
  case "$argv1" in
    "$STARTER_PATH"|*/scene-daemon) return 0 ;;
  esac

  # A zombie is not resident: it has exited but has not been reaped yet, and
  # it would otherwise keep the daemon flagged as running forever.
  state=$(awk '{print $3}' "/proc/$1/stat" 2>/dev/null)
  [ "$state" = "Z" ] && return 1

  return 1
}

# Ancestors of the current process: the shell the host spawned, the adb daemon
# behind it, and the host's own worker. Killing any of them severs the ADB
# session and forces a re-authorisation, which is why a purge could take the
# manager down with it. They are excluded from every kill list.
_ancestors() {
  a=""
  p=$(awk '{print $4}' /proc/self/stat 2>/dev/null)
  n=0
  while [ -n "$p" ] && [ "$p" != "0" ] && [ "$n" -lt 12 ]; do
    a="$a $p"
    p=$(awk '{print $4}' "/proc/$p/stat" 2>/dev/null)
    n=$((n + 1))
  done
  echo "$a"
}

daemon_pids() {
  self=$$
  parent=$(awk '{print $4}' /proc/self/stat 2>/dev/null)
  ANCESTORS=$(_ancestors)
  raw=""

  # pidof matches the process name directly and is by far the cheapest probe.
  # It only works once the payload has been launched under that name, so every
  # other lookup stays as a fallback.
  if [ -z "$raw" ] && command -v pidof >/dev/null 2>&1; then
    raw=$(pidof scene-daemon 2>/dev/null | tr ' ' '\n')
  fi

  if [ -z "$raw" ] && [ -x "$TOOLKIT/busybox" ]; then
    raw=$("$TOOLKIT/busybox" pgrep -f scene-daemon 2>/dev/null | grep -E '^[0-9]+$')
    [ -z "$raw" ] && raw=$(_ps_pids "-A -o pid= -o args=" 1)
  else
    if command -v pgrep >/dev/null 2>&1; then
      raw=$(pgrep -f scene-daemon 2>/dev/null | grep -E '^[0-9]+$')
    fi
    [ -z "$raw" ] && raw=$(_ps_pids "-A -o pid= -o args=" 1)
    [ -z "$raw" ] && raw=$(_ps_pids "-A -o pid=,args=" 1)
    [ -z "$raw" ] && raw=$(_ps_pids "-ef" 2)
    [ -z "$raw" ] && raw=$(_ps_pids "-A" 1)
  fi
  [ -z "$raw" ] && raw=$(_proc_pids)

  echo "$raw" | grep -E '^[0-9]+$' | awk '!seen[$0]++' |
    while read -r p; do
      [ "$p" = "$self" ] && continue
      [ -n "$parent" ] && [ "$p" = "$parent" ] && continue
      case " $ANCESTORS " in *" $p "*) continue ;; esac
      _valid_pid "$p" || continue
      echo "$p"
    done
}

daemon_running() {
  [ -n "$(daemon_pids)" ]
}

# --- environment gate --------------------------------------------------------
# Nothing below is meaningful if the working directory is unusable or the
# Android tooling is missing. Actions refuse to run in that state instead of
# failing deep inside with no explanation.

# Minimal precondition. Bringing up an already provisioned daemon needs a
# writable tmp directory and nothing else -- requiring am/cmd here refused
# the action on devices where Scene was already activated but those tools are
# absent from the shell PATH.
env_blockers_min() {
  b=""
  [ -d /data/local/tmp ] || b="$b tmp-missing"
  [ -w /data/local/tmp ] || b="$b tmp-readonly"
  echo "${b# }"
}

require_env_min() {
  b=$(env_blockers_min)
  if [ -n "$b" ]; then
    log "Refused: environment not ready ($b)"
    return 1
  fi
  return 0
}

env_blockers() {
  b=""
  [ -d /data/local/tmp ] || b="$b tmp-missing"
  [ -w /data/local/tmp ] || b="$b tmp-readonly"
  command -v am >/dev/null 2>&1 || b="$b no-am"
  command -v cmd >/dev/null 2>&1 || b="$b no-cmd"
  echo "${b# }"
}

env_ready() {
  [ -z "$(env_blockers)" ]
}

# Wait for the platform to become usable. At late_start the package manager
# and /data/local/tmp are often not ready yet, and a single check then aborts
# the whole activation -- which is why a boot run could silently do nothing.
# Retry for a bounded time instead of failing on the first look.
await_env() {
  i=0
  while [ "$i" -lt "$ENV_TIMEOUT" ]; do
    if env_ready; then
      return 0
    fi
    sleep 2
    i=$((i + 2))
  done
  log "Warning: environment still not ready after ${ENV_TIMEOUT}s"
  return 1
}

require_env() {
  b=$(env_blockers)
  if [ -n "$b" ]; then
    log "Refused: environment not ready ($b)"
    log "Hint: run selfcheck for a full report"
    return 1
  fi
  return 0
}

# --- provisioning ------------------------------------------------------------

provision_payload() {
  mkdir -p "$TOOLKIT"
  export PATH=$PATH:$TOOLKIT

  # Same size means the payload is already in place; copying it again is the
  # single slowest step of the routine and gains nothing.
  if await_payload "$SOURCE_DAEMON"; then
    if [ -f "$STARTER_PATH" ] && [ "$(_size "$SOURCE_DAEMON")" = "$(_size "$STARTER_PATH")" ]; then
      log "Payload current: scene-daemon ($(_size "$STARTER_PATH") bytes), copy skipped"
    else
      cp "$SOURCE_DAEMON" "$STARTER_PATH"
      chmod 777 "$STARTER_PATH"
      log "Provisioned: scene-daemon ($(_size "$STARTER_PATH") bytes)"
    fi
  else
    log "Error: scene-daemon payload not found: $SOURCE_DAEMON"
  fi

  if await_payload "$SOURCE_BUSYBOX"; then
    if [ -f "$TARGET_BUSYBOX" ] && [ "$(_size "$SOURCE_BUSYBOX")" = "$(_size "$TARGET_BUSYBOX")" ]; then
      log "Payload current: busybox ($(_size "$TARGET_BUSYBOX") bytes), copy skipped"
    else
      cp "$SOURCE_BUSYBOX" "$TARGET_BUSYBOX"
      chmod 777 "$TARGET_BUSYBOX"
      log "Provisioned: busybox ($(_size "$TARGET_BUSYBOX") bytes)"
    fi
  else
    log "Error: busybox payload not found: $SOURCE_BUSYBOX"
  fi

  # Re-linking ~40 applets means ~40 forks. Skip the whole block when the
  # links are already there and the binary has not changed.
  applet_count=$(ls -l "$TOOLKIT" 2>/dev/null | grep -c -- ' -> busybox')
  if [ "$applet_count" -ge 30 ] && [ -f "$TARGET_BUSYBOX" ]; then
    log "Payload current: $applet_count BusyBox applets, relink skipped"
  else
    log "Linking BusyBox applets"
    (cd "$TOOLKIT" 2>/dev/null || exit 1
     # One exec instead of one per applet. The loop below ran busybox ~37
     # times, and each start costs a fork plus dynamic link -- on a phone
     # that dominated the whole activation. --install -s builds every link
     # in a single process; the few that must not exist are removed after.
     if "$TARGET_BUSYBOX" --install -s . >/dev/null 2>&1; then
       for skip in sh shell swapon swapoff mkswap; do
         [ -L "./$skip" ] && rm -f "./$skip" 2>/dev/null
       done
       # --install also writes a self-referential busybox -> busybox link
       # over the real binary. Deleting it blindly removed the binary and
       # left every applet a dangling link, so restore it when that happens.
       if [ -L "./busybox" ] || [ ! -f "./busybox" ]; then
         rm -f "./busybox" 2>/dev/null
         cp "$SOURCE_BUSYBOX" "./busybox" 2>/dev/null
         chmod 777 "./busybox" 2>/dev/null
       fi
     else
       # Fallback for a build without --install: keep the old loop.
       for applet in $("$TARGET_BUSYBOX" --list 2>/dev/null); do
         case "$applet" in
         "sh"|"busybox"|"shell"|"swapon"|"swapoff"|"mkswap")
           ;;
         *)
           "$TARGET_BUSYBOX" ln -sf busybox "$applet"
           ;;
         esac
       done
     fi
     "$TARGET_BUSYBOX" ln -sf busybox busybox_1_30_1) 2>/dev/null
    log "Provisioned: $(_applet_count) BusyBox applets"
  fi

  if [ -f "$BINDER_SO" ]; then
    if [ -f /data/local/tmp/binder.so ] &&
       [ "$(_size "$BINDER_SO")" = "$(_size /data/local/tmp/binder.so)" ]; then
      log "Payload current: binder.so, copy skipped"
    else
      cp -f "$BINDER_SO" /data/local/tmp/binder.so
      log "Provisioned: binder.so ($(_size /data/local/tmp/binder.so) bytes)"
    fi
  else
    log "Info: binder.so absent, skipping"
  fi
}

# --- supervision -------------------------------------------------------------

# Set by start_daemon: 1 when this call actually spawned the daemon, 0 when it
# was already resident.
SPAWNED_NOW=0

start_daemon_async() {
  if daemon_running; then
    log "Info: scene-daemon already resident, spawn skipped"
    SPAWNED_NOW=0
    return 0
  fi

  if [ ! -f "$STARTER_PATH" ]; then
    # Start is deliberately lighter than Activate: it only has to bring the
    # process up, so a running Scene is a sufficient precondition. Requiring a
    # full provisioning pass first made this button useless on exactly the
    # device where it was needed -- Scene already up, daemon not yet spawned.
    if scene_running; then
      log "Info: Scene is running, provisioning the daemon payload only"
      if await_payload "$SOURCE_DAEMON"; then
        mkdir -p "${STARTER_PATH%/*}" 2>/dev/null
        cp "$SOURCE_DAEMON" "$STARTER_PATH"
        chmod 777 "$STARTER_PATH"
        log "Provisioned: scene-daemon -> $STARTER_PATH"
      else
        log "Scene-Daemon Fail: Scene is running but no payload at $SOURCE_DAEMON"
        return 1
      fi
    elif scene_adb_ready; then
      log "Info: Scene installed, provisioning the daemon payload only"
      mkdir -p "${STARTER_PATH%/*}" 2>/dev/null
      cp "$SOURCE_DAEMON" "$STARTER_PATH"
      chmod 777 "$STARTER_PATH"
      log "Provisioned: scene-daemon -> $STARTER_PATH"
    elif [ -f "$SOURCE_DAEMON" ]; then
      log "Info: provisioning the daemon payload from $SOURCE_DAEMON"
      mkdir -p "${STARTER_PATH%/*}" 2>/dev/null
      cp "$SOURCE_DAEMON" "$STARTER_PATH"
      chmod 777 "$STARTER_PATH"
      log "Provisioned: scene-daemon -> $STARTER_PATH"
    else
      log "Scene-Daemon Fail: no payload at $SOURCE_DAEMON and Scene is not running"
      log "Hint: use Re-provision to deploy the payload first"
      return 1
    fi
  fi
  if [ ! -x "$STARTER_PATH" ]; then
    chmod 777 "$STARTER_PATH" 2>/dev/null
  fi

  log "Spawning: $STARTER_PATH"
  nohup "$STARTER_PATH" >/dev/null 2>&1 &
  SPAWNED_PID=$!
  SPAWNED_NOW=1
  # Returns immediately. The caller applies policy and then confirms, so the
  # two costs overlap instead of adding up.
  return 2
}

# Wait for the process spawned above to prove it is alive.
confirm_daemon() {
  if [ -n "$SPAWNED_PID" ] && _valid_pid "$SPAWNED_PID"; then
    log "Daemon confirmed: pid $SPAWNED_PID"
    return 0
  fi
  i=1
  while [ "$i" -le "$START_TIMEOUT" ]; do
    if daemon_running; then
      log "Daemon confirmed: resident"
      return 0
    fi
    sleep 1
    i=$((i + 1))
  done
  if [ -n "$SPAWNED_PID" ] && _valid_pid "$SPAWNED_PID"; then
    log "Daemon confirmed: pid $SPAWNED_PID"
    return 0
  fi
  if daemon_running; then
    log "Daemon confirmed: resident"
    return 0
  fi

  log "Scene-Daemon Fail: process not resident after ${i}s"
  log "Diagnostics: payload=$(ls -l "$STARTER_PATH" 2>/dev/null | awk '{print $1, $5}')"
  diag=$(mktemp "${TMPDIR:-/data/local/tmp}/sdb_diag.XXXXXX" 2>/dev/null || echo "${TMPDIR:-/data/local/tmp}/sdb_diag.$$")
  ("$STARTER_PATH" >"$diag" 2>&1 </dev/null & echo $! >"$diag.pid") 2>/dev/null
  dp=$(cat "$diag.pid" 2>/dev/null)
  j=0
  while [ "$j" -lt 3 ] && [ -n "$dp" ] && pid_alive "$dp"; do
    sleep 1
    j=$((j + 1))
  done
  [ -n "$dp" ] && kill -9 "$dp" 2>/dev/null
  out=$(head -5 "$diag" 2>/dev/null)
  rm -f "$diag" "$diag.pid" 2>/dev/null
  [ -n "$out" ] && log "Diagnostics: stdout/stderr -> $out"
  return 1
}

# Synchronous form for the standalone start action.
start_daemon() {
  start_daemon_async
  rc=$?
  if [ "$rc" != "2" ]; then
    # rc 0 = already resident. Confirmation already logged OK there.
    [ "$rc" = "0" ] && log "Scene-Daemon OK: resident, pid $(daemon_pids | head -1)"
    return "$rc"
  fi
  if confirm_daemon; then
    # A single closing OK line, so Start reads the same as Activate instead of
    # stopping at "confirmed" with no verdict.
    log "Scene-Daemon OK: resident, pid $(daemon_pids | head -1)"
    return 0
  fi
  return 1
}

# Is this specific pid still alive? kill -0 is a single syscall, far cheaper
# than re-scanning every /proc entry -- which is what made Terminate/Purge feel
# frozen on devices with many running processes.
pid_alive() {
  kill -0 "$1" 2>/dev/null
}

# Strict variant used by the CLI: terminating something that is not running
# is a no-op that used to be reported as success.
stop_daemon() {
  # Killing a process needs no am/cmd. Gating on require_env refused the
  # action outright on devices where those tools are absent from PATH, so the
  # daemon survived a "successful" stop and the panel kept saying running.
  require_env_min || return 1
  if ! daemon_running; then
    log "Refused: scene-daemon not resident, nothing to terminate"
    return 3
  fi
  terminate_daemon
}

terminate_daemon() {
  pids=$(daemon_pids)
  if [ -z "$pids" ]; then
    log "Info: scene-daemon not resident"
    return 0
  fi

  log "Terminating: scene-daemon (pid: $(echo $pids))"
  kill $pids 2>/dev/null

  # Wait only on the pids we signalled, not on a full rescan each round.
  i=0
  while [ "$i" -lt "$TERM_TIMEOUT" ]; do
    pending=""
    for p in $pids; do
      pid_alive "$p" && pending="$pending $p"
    done
    [ -z "$pending" ] && break
    sleep 1
    i=$((i + 1))
  done

  pending=""
  for p in $pids; do
    pid_alive "$p" && pending="$pending $p"
  done

  if [ -n "$pending" ]; then
    kill -9 $pending 2>/dev/null
    sleep 1
  fi

  # Re-scan rather than only re-checking the pids we signalled: a daemon that
  # respawned, or one that was never in the first list, has to be caught here
  # or the panel keeps reporting "resident" after a stop.
  left=$(daemon_pids)
  if [ -n "$left" ]; then
    kill -9 $left 2>/dev/null
    sleep 1
    left=$(daemon_pids)
  fi

  if [ -n "$left" ]; then
    log "Terminate Fail: still resident (pid:$(echo $left))"
    return 1
  fi
  log "Terminated: scene-daemon (pid: $(echo $pids))"
  # A deliberate stop is a decision, not an accident: do not undo it at the
  # next boot.
  suspend_auto terminate
  return 0
}

# Bringing the Scene UI forward is only meaningful once the daemon is actually
# resident. Launching it earlier (or after a failed spawn) pulls an app to the
# foreground that then has nothing to attach to.
# Seconds during which a repeat launch is suppressed. Scene re-enters its own
# splash while ADB mode is being granted; launching again inside that window is
# what throws the user back out before the dialog finishes.
# Manual entries (action button, WebUI run) launch whenever the daemon is OK,
# even if it was already resident -- the user asked for it explicitly. Boot and
# module activation stay silent via SDB_LAUNCH_SCENE=0 in service.sh.
LAUNCH_FORCE="${SDB_LAUNCH_FORCE:-1}"

LAUNCH_COOLDOWN="${SDB_LAUNCH_COOLDOWN:-120}"
LAUNCH_STAMP="/data/local/tmp/.scene_daemon_bootstrap.launch"

_now() { date +%s 2>/dev/null; }

# Byte size, or empty when unreadable. Comparing sizes is far cheaper than
# a checksum and is enough to tell "already installed" from "changed".
_size() {
  ls -l "$1" 2>/dev/null | awk '{print $5}'
}

launch_allowed() {
  [ "$LAUNCH_COOLDOWN" -gt 0 ] 2>/dev/null || return 0
  now=$(_now)
  [ -n "$now" ] || return 0
  last=$(cat "$LAUNCH_STAMP" 2>/dev/null)
  case "${last:-}" in
    ''|*[!0-9]*) return 0 ;;
  esac
  elapsed=$((now - last))
  [ "$elapsed" -ge "$LAUNCH_COOLDOWN" ] && return 0
  log "Info: Scene launch suppressed, launched ${elapsed}s ago (cooldown ${LAUNCH_COOLDOWN}s)"
  return 1
}

launch_mark() {
  now=$(_now)
  [ -n "$now" ] && echo "$now" >"$LAUNCH_STAMP" 2>/dev/null
  return 0
}

# One launch per script run. Even if something calls launch_scene twice, the
# second call is a no-op -- the splash is brought forward exactly once.
LAUNCH_DONE=0

launch_scene() {
  if [ "$LAUNCH_SCENE" != "1" ]; then
    log "Info: Scene launch disabled by SDB_LAUNCH_SCENE=0"
    return 0
  fi
  if [ "$LAUNCH_DONE" = "1" ]; then
    log "Info: Scene launch already done this run, skipping"
    return 0
  fi
  launch_allowed || return 0
  # FLAG_ACTIVITY_NEW_TASK only. The original 0x10008000 also carried
  # FLAG_ACTIVITY_CLEAR_TASK (0x00008000), which tears down an existing Scene
  # task and rebuilds it -- on screen that reads as the app jumping forward
  # twice, once for the destroyed instance and once for the new one.
  am start -n "$scene/.activities.ActivityStartSplash" --es port "$port" \
      -f "${SDB_LAUNCH_FLAG:-0x10000000}" >/dev/null 2>&1
  LAUNCH_DONE=1
  launch_mark
  log "Launched: Scene splash activity"
}

apply_policy() {
  cmd package compile -m speed "$scene" >/dev/null 2>&1 &

  dumpsys deviceidle whitelist +"$scene" 2>&1 >/dev/null
  cmd appops set "$scene" RUN_IN_BACKGROUND allow 2>&1 >/dev/null
  cmd appops set "$scene" RUN_ANY_IN_BACKGROUND allow 2>&1 >/dev/null
  am set-standby-bucket "$scene" active 2>&1 >/dev/null
  am set-inactive --user 0 "$scene" false 2>&1 >/dev/null
  am set-bg-restriction-level --user 0 "$scene" unrestricted 2>&1 >/dev/null
  am set-foreground-service-delegate --user 0 "$scene" start 2>&1 >/dev/null
  am unfreeze --sticky "$scene" 2>&1 >/dev/null
  log "Applied: standby bucket / appops / deviceidle policy"
  echo "applied=$(date '+%m-%d %H:%M:%S')" >"$POLICY_FILE" 2>/dev/null
}

bootstrap() {
  # Automatic runs (boot / module enable) respect the suspension set by a stop
  # or purge. An explicit run clears it, so provisioning comes back from then
  # on without anything else to remember.
  if [ "$SDB_AUTO_RUN" = "1" ] && auto_suspended; then
    log "Info: automatic provisioning suspended after the last terminate/purge"
    log "Info: run Re-provision once to restore automatic startup"
    return 0
  fi
  resume_auto
  log "Bootstrap started"
  # Provisioning and spawning need only a writable /data/local/tmp. Gating the
  # whole routine on am/cmd being present in PATH aborted the automatic boot
  # run outright on ADB-only devices, where those tools are not on the service
  # PATH -- the daemon was then never deployed and the panel stayed empty
  # until it was triggered by hand. Only the policy step needs them, and it is
  # skipped with a note when they are unavailable.
  if ! require_env_min; then
    log "Aborted: bootstrap"
    return 1
  fi

  # Fast path. Scene already in ADB mode with a resident daemon and a
  # complete payload means there is nothing to deploy -- re-running the full
  # copy and BusyBox install every time is what made a repeat activation
  # feel slower than the original one-shot script.
  if daemon_running && [ -x "$STARTER_PATH" ] && [ -x "$TARGET_BUSYBOX" ]; then
    log "Info: daemon resident and payload complete, provisioning skipped"
    launch_or_note 1
    return 0
  fi

  provision_payload
  log ""

  # No payload, no daemon: stop here rather than spawning a binary that
  # cannot exist and reporting a misleading failure later.
  if [ ! -f "$STARTER_PATH" ]; then
    log "Abort: scene-daemon payload unavailable ($SOURCE_DAEMON)"
    log "Aborted: bootstrap"
    return 1
  fi

  # Overlap: spawn first, apply policy while the daemon initialises, then
  # confirm. Running these in series is what pushed activation past 30s --
  # the policy block costs one round trip per am/cmd call and was previously
  # paid on top of the full spawn wait.
  start_daemon_async
  spawned_now=$?
  # 0 = already resident, 2 = spawned (confirm later), 1 = failed

  # Policy FIRST, launch LAST. Every command here is an `am` call
  # (set-standby-bucket / set-inactive / unfreeze / set-bg-restriction-level /
  # set-foreground-service-delegate). Running them after the launch reassigns
  # task ownership and drags the previous task back to the foreground --
  # thrown back out of Scene before reaching ADB mode. Done beforehand, the
  # launch is the final action and nothing undoes it.
  # Policy relaxes background restrictions and keeps the daemon alive, but it
  # is a best-effort step: without am/cmd it cannot be issued, and refusing the
  # whole activation because of it would leave the device worse off than
  # applying everything else and noting the omission.
  if env_ready; then
    apply_policy
  else
    log "Info: policy skipped, am/cmd unavailable ($(env_blockers))"
  fi

  if [ "$spawned_now" = "0" ]; then
    daemon_ok=1
  elif [ "$spawned_now" = "2" ]; then
    if confirm_daemon; then daemon_ok=1; else daemon_ok=0; fi
  else
    daemon_ok=0
  fi

  launch_or_note "$daemon_ok"
}

# Gate the UI launch on a successful spawn: no "Scene-Daemon OK", no jump.
  # Only a daemon that this very call brought up justifies pulling Scene to
# the foreground; an already resident one means the user is likely inside
# Scene already, and re-launching the splash throws them back out.
# Manual entry (action.sh, SDB_LAUNCH_FORCE=1) launches whenever the daemon
# is OK -- already resident or not -- because that button exists precisely to
# hand over to Scene. Background activation never reaches this branch
# (service.sh and the WebUI both set SDB_LAUNCH_SCENE=0 and stay silent).
# One-shot deployment. Detects precisely, and if Scene has not been activated
# yet runs a silent activation before deploying. Never brings Scene to the
# foreground, and works whether or not Scene has ever been opened.
redeploy() {
  # An explicit Re-provision is the operator asking for the daemon back, so it
  # also ends the suspension that a previous stop/purge had set. Automatic
  # provisioning resumes from here on.
  resume_auto
  log "Re-provision started"

  # Precise detection first: report what is actually there, never what the
  # last run left behind.
  pids=$(daemon_pids)
  if [ -n "$pids" ]; then det_daemon="resident"; else det_daemon="not resident"; fi
  if _usable "$STARTER_PATH" && _usable "$TARGET_BUSYBOX"; then
    det_payload="complete"
  else
    det_payload="incomplete"
  fi
  if scene_running; then det_scene="running"; else det_scene="not running"; fi
  log "Detected: scene $det_scene, daemon $det_daemon, payload $det_payload"

  # Same reasoning as bootstrap: deployment and spawn need only a writable
  # tmp; the policy step is skipped on its own when am/cmd are unavailable.
  if ! require_env_min; then
    log "Aborted: re-provision"
    return 1
  fi

  # Always run the whole chain. Delegating to bootstrap took its fast path
  # whenever a daemon was already resident -- it then deployed nothing and
  # printed nothing, so the button looked broken on an already-activated
  # device, which is exactly when it is most useful.
  provision_payload
  log ""

  if [ ! -f "$STARTER_PATH" ]; then
    log "Abort: scene-daemon payload unavailable ($SOURCE_DAEMON)"
    log "Aborted: re-provision"
    return 1
  fi

  start_daemon_async
  spawned_now=$?

  apply_policy

  if [ "$spawned_now" = "0" ]; then
    daemon_ok=1
  elif [ "$spawned_now" = "2" ]; then
    if confirm_daemon; then daemon_ok=1; else daemon_ok=0; fi
  else
    daemon_ok=0
  fi

  [ "$daemon_ok" = "1" ]
}

launch_or_note() {
  if [ "$1" != "1" ]; then
    log "Scene-Daemon Fail: process not resident after ${SDB_START_TIMEOUT:-6}s"
    log "Info: Scene launch skipped, daemon not resident"
    return 0
  fi
  # Full handover report before the jump: the operator needs to see what was
  # achieved and what happens next, not just a bare OK.
  log "Scene-Daemon OK: resident, pid $(daemon_pids | head -1), payload ready, $(_applet_count) applets"
  log "Payload: scene-daemon $([ -f "$STARTER_PATH" ] && echo ready || echo missing), busybox $([ -f "$TARGET_BUSYBOX" ] && echo ready || echo missing), applets $(_applet_count)"
  log "Policy: standby bucket + appops + deviceidle applied"
  if [ "$LAUNCH_FORCE" = "1" ] || [ "$SPAWNED_NOW" = "1" ]; then
    # Let the daemon settle first: launching while it is still initialising
    # can leave Scene's splash with nothing to attach to, and it then
    # finishes straight back to the previous task.
    sleep "${SDB_LAUNCH_DELAY:-0.3}" 2>/dev/null || sleep 1
    log "Handover: starting Scene splash activity"
    launch_scene
  else
    log "Info: Scene launch skipped, daemon was already resident"
  fi
}

# --- scene adb mode ----------------------------------------------------------
# True when Scene is already able to run in ADB mode on its own: the package
# is installed and its daemon payload is on external storage. In that state
# starting the daemon does not require the provisioning routine first -- the
# original script forced a full bootstrap even when everything was already in
# place, which is what made a plain "start" unnecessarily slow.
# Is the Scene app itself alive? That is the real signal that ADB mode has
# been granted and its daemon payload is available -- checking only for an
# installed package or an existing file rejects a device where Scene is
# running right now.
scene_running() {
  if command -v pidof >/dev/null 2>&1; then
    pidof "$scene" >/dev/null 2>&1 && return 0
  fi
  # ps reports the process name without needing to read another app's
  # /proc entry, which the shell user is often not allowed to do.
  if command -v ps >/dev/null 2>&1; then
    # The grep's own command line contains the package name, so an unfiltered
    # match would report Scene as running on a device where it is not.
    ps -A 2>/dev/null | grep -v grep | grep -q -- "$scene" && return 0
    ps -ef 2>/dev/null | grep -v grep | grep -q -- "$scene" && return 0
  fi
  for d in /proc/[0-9]*; do
    c=$(cat "$d/cmdline" 2>/dev/null) || continue
    case "$c" in
      *"$scene"*) return 0 ;;
    esac
  done
  return 1
}

scene_adb_ready() {
  # Scene running is enough on its own: it implies ADB mode is active and the
  # payload can be provisioned on demand.
  scene_running && return 0
  _pkg_installed || return 1
  [ -f "$SOURCE_DAEMON" ] || [ -f "$STARTER_PATH" ] || return 1
  return 0
}

# Precise usability check. -x follows a symlink to a missing target on some
# shells and reports success, which is how the panel could claim a payload was
# present when every applet pointed at nothing.
_usable() {
  [ -e "$1" ] || return 1
  if [ -L "$1" ]; then
    t=$(readlink "$1" 2>/dev/null) || return 1
    case "$t" in
      /*) [ -e "$t" ] || return 1 ;;
      *)  [ -e "${1%/*}/$t" ] || return 1 ;;
    esac
  fi
  [ -f "$1" ] || return 1
  [ -x "$1" ] || return 1
  return 0
}

# Count applet links that actually resolve.
_applet_count() {
  ls -1F "$TOOLKIT" 2>/dev/null | grep -c '@$'
}

# --- auto-provisioning suspension -------------------------------------------
# After a deliberate stop or purge, an automatic boot-time provisioning would
# put back exactly what the operator just removed. The run is therefore
# suspended until a Re-provision is issued by hand, which clears the marker and
# restores automatic behaviour from then on.
SDB_SUSPEND_FILE="${SDB_SUSPEND_FILE:-/data/local/tmp/.scene_daemon_bootstrap.suspend}"

suspend_auto(){
  echo "reason=${1:-manual} at=$(date '+%m-%d %H:%M:%S')" >"$SDB_SUSPEND_FILE" 2>/dev/null
}

resume_auto(){
  rm -f "$SDB_SUSPEND_FILE" 2>/dev/null
}

auto_suspended(){
  [ -f "$SDB_SUSPEND_FILE" ]
}

# --- policy cache ---
# Android resets standby buckets, appops and idle whitelists after a system
# update or an application restart, so "applied once" is not "applied now".
# The marker records intent; one cheap command verifies it still holds.
POLICY_FILE="${TMPDIR:-/data/local/tmp}/.scene_daemon_bootstrap.policy"

policy_applied() {
  [ -f "$POLICY_FILE" ] || return 1
  # Verify rather than trust the marker: a stale file would grey out the
  # button exactly when re-applying is what the device needs.
  if command -v am >/dev/null 2>&1; then
    bucket=$(am get-standby-bucket "$scene" 2>/dev/null | tr -cd '0-9')
    if [ -n "$bucket" ] && [ "$bucket" != "5" ] && [ "$bucket" != "10" ]; then
      # Got a reading and it is not ACTIVE(5)/EXEMPTED(10): the policy was
      # reset since we applied it.
      rm -f "$POLICY_FILE" 2>/dev/null
      return 1
    fi
  fi
  return 0
}

# --- status cache -------------------------------------------------------------
# Written by service.sh at activation/boot time, so the WebUI can show a
# populated panel by reading one small file instead of running the full probe
# while the page is still laying out -- that combination is what froze the
# first open.
STATUS_CACHE="${SDB_STATUS_CACHE:-/data/local/tmp/.scene_daemon_bootstrap.status}"

write_status_cache() {
  status >"$STATUS_CACHE" 2>/dev/null
}

read_status_cache() {
  [ -f "$STATUS_CACHE" ] && cat "$STATUS_CACHE" 2>/dev/null
}

# --- reporting ---------------------------------------------------------------

status() {
  echo "MODULE_DIR=$MODDIR"
  echo "MODULE_ID=$(basename "$MODDIR" 2>/dev/null)"

  if _pkg_installed; then
    echo "PACKAGE=installed"
  else
    echo "PACKAGE=absent"
  fi

  # Probe once: daemon_running() plus a second daemon_pids() call would repeat
  # the most expensive step of the whole query.
  pids=$(daemon_pids)
  if [ -n "$pids" ]; then
    echo "DAEMON=running"
    echo "DAEMON_PIDS=$(echo "$pids" | tr '\n' ' ' | sed 's/ *$//')"
  else
    echo "DAEMON=stopped"
    echo "DAEMON_PIDS="
  fi

  if _usable "$STARTER_PATH"; then
    echo "PAYLOAD_DAEMON=present"
  else
    echo "PAYLOAD_DAEMON=absent"
  fi
  if _usable "$TARGET_BUSYBOX"; then
    echo "PAYLOAD_BUSYBOX=present"
  else
    echo "PAYLOAD_BUSYBOX=absent"
  fi
  applets=$(_applet_count)
  echo "APPLETS=${applets:-0}"
  echo "PAYLOAD_BINDER=$([ -f /data/local/tmp/binder.so ] && echo present || echo absent)"

  echo "SOURCE_DAEMON=$([ -f "$SOURCE_DAEMON" ] && echo present || echo absent)"
  echo "SOURCE_BUSYBOX=$([ -f "$SOURCE_BUSYBOX" ] && echo present || echo absent)"
  echo "SOURCE_BINDER=$([ -f "$BINDER_SO" ] && echo present || echo absent)"
  echo "LOG_FILE=$([ -f "$LOG_FILE" ] && echo present || echo absent)"

  if env_ready; then
    echo "ENV_READY=yes"
  else
    echo "ENV_READY=no"
    echo "ENV_BLOCKERS=$(env_blockers)"
  fi
  # Reported separately: a missing am/cmd blocks policy work but must not
  # lock out provisioning or the daemon, which only need a writable tmp.
  minb=$(env_blockers_min)
  if [ -n "$minb" ]; then
    echo "ENV_MIN_READY=no"
    echo "ENV_MIN_BLOCKERS=$minb"
  else
    echo "ENV_MIN_READY=yes"
  fi
  # Lets the panel grey out "Apply Policy" once it has actually been applied,
  # and un-grey it again after Android resets those settings.
  if policy_applied; then
    echo "POLICY=applied"
  else
    echo "POLICY=none"
  fi
  if auto_suspended; then
    echo "SUSPEND=yes"
  else
    echo "SUSPEND=no"
  fi
}

# Environment report: everything needed to explain a non-functional plugin.
selfcheck() {
  echo "UID=$(id -u 2>/dev/null)"
  echo "SHELL=$0"
  echo "TMP_DIR=$([ -d /data/local/tmp ] && echo present || echo absent)"
  echo "TMP_WRITABLE=$([ -w /data/local/tmp ] && echo yes || echo no)"
  echo "PAYLOAD_DAEMON=$([ -x "$STARTER_PATH" ] && echo present || echo absent)"
  echo "PAYLOAD_BUSYBOX=$([ -x "$TARGET_BUSYBOX" ] && echo present || echo absent)"
  echo "APPLETS=$(ls -l "$TOOLKIT" 2>/dev/null | grep -c -- ' -> busybox')"
  echo "SOURCE_DAEMON=$([ -f "$SOURCE_DAEMON" ] && echo present || echo absent)"
  echo "SOURCE_BUSYBOX=$([ -f "$SOURCE_BUSYBOX" ] && echo present || echo absent)"
  echo "PKG_QUERY=$(cmd package list packages 2>/dev/null | grep -c "^package:$scene$")"
  echo "PS=$(command -v ps >/dev/null 2>&1 && echo yes || echo no)"
  echo "PGREP=$(command -v pgrep >/dev/null 2>&1 && echo yes || echo no)"
  echo "AM=$(command -v am >/dev/null 2>&1 && echo yes || echo no)"
  echo "CMD=$(command -v cmd >/dev/null 2>&1 && echo yes || echo no)"
  echo "DUMPSYS=$(command -v dumpsys >/dev/null 2>&1 && echo yes || echo no)"
  echo "DAEMON_PIDS=$(daemon_pids | tr '\n' ' ' | sed 's/ *$//')"
  if env_ready; then
    echo "ENV_READY=yes"
  else
    echo "ENV_READY=no"
    echo "ENV_BLOCKERS=$(env_blockers)"
  fi
}

# Remove everything this module wrote to the device, except the payload that
# purge_payload() owns: log, progress stream, status cache, launch stamp and
# any diagnostic scratch file.
clean_workspace() {
  n=0
  for f in "$LOG_FILE" "$PROGRESS_FILE" "$STATUS_CACHE" "$LAUNCH_STAMP"; do
    if [ -f "$f" ]; then
      rm -f "$f" 2>/dev/null && n=$((n + 1))
    fi
  done
  for f in "${TMPDIR:-/data/local/tmp}"/sdb_diag.*; do
    [ -e "$f" ] && rm -f "$f" 2>/dev/null && n=$((n + 1))
  done
  # Reported on stdout only. log() appends to the file that was just deleted,
  # which would resurrect it holding exactly one line and defeat the purpose.
  echo "Cleaned: $n runtime file(s) removed"
}

purge_payload() {
  # Stop first. Deleting the payload out from under a running process does not
  # stop it -- the kernel keeps the executable alive until it exits -- so the
  # panel would show a running daemon with no payload on disk.
  if [ -n "$(daemon_pids)" ]; then
    log "Stopping: scene-daemon before removing its payload"
    terminate_daemon
  fi

  # Remove only what this module deployed. /data/local/tmp is shared with the
  # host and with adb shell itself, so `rm -rf` on the toolkit directory can
  # take out something that is not ours -- and the directory is recreated by
  # others, so a blanket delete is never safe to repeat.
  rm -f "$STARTER_PATH"
  if [ -d "$TOOLKIT" ]; then
    rm -f "$TARGET_BUSYBOX" 2>/dev/null
    for f in "$TOOLKIT"/*; do
      [ -L "$f" ] && rm -f "$f" 2>/dev/null
    done
    rmdir "$TOOLKIT" 2>/dev/null   # only succeeds when nothing else is left
  fi
  rm -f /data/local/tmp/binder.so
  rm -f "$POLICY_FILE" 2>/dev/null
  log "Purged: scene-daemon / toolkit / binder.so"
  suspend_auto purge
}

revert_policy() {
  dumpsys deviceidle whitelist -"$scene" 2>&1 >/dev/null
  cmd appops set "$scene" RUN_IN_BACKGROUND default 2>&1 >/dev/null
  cmd appops set "$scene" RUN_ANY_IN_BACKGROUND default 2>&1 >/dev/null
  am set-standby-bucket "$scene" active 2>&1 >/dev/null
  log "Reverted: standby bucket / appops / deviceidle policy"
}
